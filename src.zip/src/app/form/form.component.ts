
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  registerForm!: FormGroup;
  submitted!:boolean;


  constructor(private FormBuilder: FormBuilder){}

  ngOnInit() {
    this.registerForm = this.FormBuilder.group({
      firstName: ['', { validators: [Validators.required] }],
      lastName: ['', Validators.required],
      email:  ['', Validators.required],      
      phoneNumber:  ['', Validators.required],
      password: ['', Validators.required],
      nationality: ['', Validators.required],
      passportNumber:  ['', Validators.required],
      permanentAddress:  ['', Validators.required],
      officeAddress:  ['', Validators.required],
      personalIdentificationNumber:  ['', Validators.required],
      })
    };
    onSubmit(){
      console.log(this.registerForm)
    }
  }

